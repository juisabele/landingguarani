const formToJSON = elements => [].reduce.call(elements, (data, element) => {

      data[element.name] = element.value;
      console.log(data)
  return data;
}, {});

const handleFormSubmit = event => {
  //event.preventDefault();
  const data = formToJSON(form.getElementsByClassName('cadastro'));
  return data
};

const form = document.getElementsByClassName('formCadastro')[0];
form.addEventListener('submit', handleFormSubmit);
